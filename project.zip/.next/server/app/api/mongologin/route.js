"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/mongologin/route";
exports.ids = ["app/api/mongologin/route"];
exports.modules = {

/***/ "mongodb":
/*!**************************!*\
  !*** external "mongodb" ***!
  \**************************/
/***/ ((module) => {

module.exports = require("mongodb");

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ "os":
/*!*********************!*\
  !*** external "os" ***!
  \*********************/
/***/ ((module) => {

module.exports = require("os");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fmongologin%2Froute&page=%2Fapi%2Fmongologin%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fmongologin%2Froute.js&appDir=%2Fworkspaces%2Fnexttemp%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fworkspaces%2Fnexttemp&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fmongologin%2Froute&page=%2Fapi%2Fmongologin%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fmongologin%2Froute.js&appDir=%2Fworkspaces%2Fnexttemp%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fworkspaces%2Fnexttemp&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   originalPathname: () => (/* binding */ originalPathname),\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   requestAsyncStorage: () => (/* binding */ requestAsyncStorage),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/future/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(rsc)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _workspaces_nexttemp_app_api_mongologin_route_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/api/mongologin/route.js */ \"(rsc)/./app/api/mongologin/route.js\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/mongologin/route\",\n        pathname: \"/api/mongologin\",\n        filename: \"route\",\n        bundlePath: \"app/api/mongologin/route\"\n    },\n    resolvedPagePath: \"/workspaces/nexttemp/app/api/mongologin/route.js\",\n    nextConfigOutput,\n    userland: _workspaces_nexttemp_app_api_mongologin_route_js__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { requestAsyncStorage, staticGenerationAsyncStorage, serverHooks } = routeModule;\nconst originalPathname = \"/api/mongologin/route\";\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        serverHooks,\n        staticGenerationAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIuanM/bmFtZT1hcHAlMkZhcGklMkZtb25nb2xvZ2luJTJGcm91dGUmcGFnZT0lMkZhcGklMkZtb25nb2xvZ2luJTJGcm91dGUmYXBwUGF0aHM9JnBhZ2VQYXRoPXByaXZhdGUtbmV4dC1hcHAtZGlyJTJGYXBpJTJGbW9uZ29sb2dpbiUyRnJvdXRlLmpzJmFwcERpcj0lMkZ3b3Jrc3BhY2VzJTJGbmV4dHRlbXAlMkZhcHAmcGFnZUV4dGVuc2lvbnM9dHN4JnBhZ2VFeHRlbnNpb25zPXRzJnBhZ2VFeHRlbnNpb25zPWpzeCZwYWdlRXh0ZW5zaW9ucz1qcyZyb290RGlyPSUyRndvcmtzcGFjZXMlMkZuZXh0dGVtcCZpc0Rldj10cnVlJnRzY29uZmlnUGF0aD10c2NvbmZpZy5qc29uJmJhc2VQYXRoPSZhc3NldFByZWZpeD0mbmV4dENvbmZpZ091dHB1dD0mcHJlZmVycmVkUmVnaW9uPSZtaWRkbGV3YXJlQ29uZmlnPWUzMCUzRCEiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQXNHO0FBQ3ZDO0FBQ2M7QUFDQTtBQUM3RTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsZ0hBQW1CO0FBQzNDO0FBQ0EsY0FBYyx5RUFBUztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsWUFBWTtBQUNaLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQSxRQUFRLGlFQUFpRTtBQUN6RTtBQUNBO0FBQ0EsV0FBVyw0RUFBVztBQUN0QjtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ3VIOztBQUV2SCIsInNvdXJjZXMiOlsid2VicGFjazovL25leHR0ZW1wLz8yZDI5Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFwcFJvdXRlUm91dGVNb2R1bGUgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUtbW9kdWxlcy9hcHAtcm91dGUvbW9kdWxlLmNvbXBpbGVkXCI7XG5pbXBvcnQgeyBSb3V0ZUtpbmQgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUta2luZFwiO1xuaW1wb3J0IHsgcGF0Y2hGZXRjaCBhcyBfcGF0Y2hGZXRjaCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2xpYi9wYXRjaC1mZXRjaFwiO1xuaW1wb3J0ICogYXMgdXNlcmxhbmQgZnJvbSBcIi93b3Jrc3BhY2VzL25leHR0ZW1wL2FwcC9hcGkvbW9uZ29sb2dpbi9yb3V0ZS5qc1wiO1xuLy8gV2UgaW5qZWN0IHRoZSBuZXh0Q29uZmlnT3V0cHV0IGhlcmUgc28gdGhhdCB3ZSBjYW4gdXNlIHRoZW0gaW4gdGhlIHJvdXRlXG4vLyBtb2R1bGUuXG5jb25zdCBuZXh0Q29uZmlnT3V0cHV0ID0gXCJcIlxuY29uc3Qgcm91dGVNb2R1bGUgPSBuZXcgQXBwUm91dGVSb3V0ZU1vZHVsZSh7XG4gICAgZGVmaW5pdGlvbjoge1xuICAgICAgICBraW5kOiBSb3V0ZUtpbmQuQVBQX1JPVVRFLFxuICAgICAgICBwYWdlOiBcIi9hcGkvbW9uZ29sb2dpbi9yb3V0ZVwiLFxuICAgICAgICBwYXRobmFtZTogXCIvYXBpL21vbmdvbG9naW5cIixcbiAgICAgICAgZmlsZW5hbWU6IFwicm91dGVcIixcbiAgICAgICAgYnVuZGxlUGF0aDogXCJhcHAvYXBpL21vbmdvbG9naW4vcm91dGVcIlxuICAgIH0sXG4gICAgcmVzb2x2ZWRQYWdlUGF0aDogXCIvd29ya3NwYWNlcy9uZXh0dGVtcC9hcHAvYXBpL21vbmdvbG9naW4vcm91dGUuanNcIixcbiAgICBuZXh0Q29uZmlnT3V0cHV0LFxuICAgIHVzZXJsYW5kXG59KTtcbi8vIFB1bGwgb3V0IHRoZSBleHBvcnRzIHRoYXQgd2UgbmVlZCB0byBleHBvc2UgZnJvbSB0aGUgbW9kdWxlLiBUaGlzIHNob3VsZFxuLy8gYmUgZWxpbWluYXRlZCB3aGVuIHdlJ3ZlIG1vdmVkIHRoZSBvdGhlciByb3V0ZXMgdG8gdGhlIG5ldyBmb3JtYXQuIFRoZXNlXG4vLyBhcmUgdXNlZCB0byBob29rIGludG8gdGhlIHJvdXRlLlxuY29uc3QgeyByZXF1ZXN0QXN5bmNTdG9yYWdlLCBzdGF0aWNHZW5lcmF0aW9uQXN5bmNTdG9yYWdlLCBzZXJ2ZXJIb29rcyB9ID0gcm91dGVNb2R1bGU7XG5jb25zdCBvcmlnaW5hbFBhdGhuYW1lID0gXCIvYXBpL21vbmdvbG9naW4vcm91dGVcIjtcbmZ1bmN0aW9uIHBhdGNoRmV0Y2goKSB7XG4gICAgcmV0dXJuIF9wYXRjaEZldGNoKHtcbiAgICAgICAgc2VydmVySG9va3MsXG4gICAgICAgIHN0YXRpY0dlbmVyYXRpb25Bc3luY1N0b3JhZ2VcbiAgICB9KTtcbn1cbmV4cG9ydCB7IHJvdXRlTW9kdWxlLCByZXF1ZXN0QXN5bmNTdG9yYWdlLCBzdGF0aWNHZW5lcmF0aW9uQXN5bmNTdG9yYWdlLCBzZXJ2ZXJIb29rcywgb3JpZ2luYWxQYXRobmFtZSwgcGF0Y2hGZXRjaCwgIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWFwcC1yb3V0ZS5qcy5tYXAiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fmongologin%2Froute&page=%2Fapi%2Fmongologin%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fmongologin%2Froute.js&appDir=%2Fworkspaces%2Fnexttemp%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fworkspaces%2Fnexttemp&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./app/api/mongologin/route.js":
/*!*************************************!*\
  !*** ./app/api/mongologin/route.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   GET: () => (/* binding */ GET),\n/* harmony export */   POST: () => (/* binding */ POST)\n/* harmony export */ });\nconst { MongoClient } = __webpack_require__(/*! mongodb */ \"mongodb\");\nconst { NextResponse } = __webpack_require__(/*! next/server */ \"(rsc)/./node_modules/next/dist/api/server.js\");\nconst dotenv = __webpack_require__(/*! dotenv */ \"(rsc)/./node_modules/dotenv/lib/main.js\");\ndotenv.config();\nconst res = NextResponse;\nconst dbClient = new MongoClient(process.env.Atlas_URI);\nasync function GET(req) {\n    try {\n        await dbClient.connect();\n        const dataBase = dbClient.db(process.env.Atlas_DB);\n        const collection = dataBase.collection(\"record\");\n        const cursor = collection.find();\n        const arr = [];\n        for await (const data of cursor){\n            arr.push(data);\n        }\n        // return res.json({ 'response': 'Api called Successfully!' })\n        return res.json(arr);\n    } catch (err) {\n        console.error(err);\n        return res.json({\n            \"response\": \"Internel Server Error!\"\n        });\n    } finally{\n        dbClient.close();\n    }\n}\nasync function POST(req) {\n    try {\n        await dbClient.connect();\n        console.log(\"client connected\");\n        let data = await req.json();\n        const dataBase = dbClient.db(process.env.Atlas_DB);\n        const collection = dataBase.collection(\"record\");\n        const result = await collection.insertOne(data);\n        // console.log(result);\n        return res.json({\n            \"response\": \"Data Inserted Successfully!\",\n            \"User\": data.Username\n        });\n    } catch (err) {\n        // console.error(err);\n        return res.json({\n            \"response\": \"Internel Server Error!\"\n        });\n    } finally{\n        dbClient.close();\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvYXBpL21vbmdvbG9naW4vcm91dGUuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSxNQUFNLEVBQUVBLFdBQVcsRUFBRSxHQUFHQyxtQkFBT0EsQ0FBQyx3QkFBUztBQUN6QyxNQUFNLEVBQUVDLFlBQVksRUFBRSxHQUFHRCxtQkFBT0EsQ0FBQyxpRUFBYTtBQUM5QyxNQUFNRSxTQUFTRixtQkFBT0EsQ0FBQyx1REFBUTtBQUMvQkUsT0FBT0MsTUFBTTtBQUNiLE1BQU1DLE1BQU1IO0FBQ1osTUFBTUksV0FBVyxJQUFJTixZQUFZTyxRQUFRQyxHQUFHLENBQUNDLFNBQVM7QUFFL0MsZUFBZUMsSUFBSUMsR0FBRztJQUN6QixJQUFJO1FBQ0EsTUFBTUwsU0FBU00sT0FBTztRQUN0QixNQUFNQyxXQUFXUCxTQUFTUSxFQUFFLENBQUNQLFFBQVFDLEdBQUcsQ0FBQ08sUUFBUTtRQUNqRCxNQUFNQyxhQUFhSCxTQUFTRyxVQUFVLENBQUM7UUFDdkMsTUFBTUMsU0FBT0QsV0FBV0UsSUFBSTtRQUM1QixNQUFNQyxNQUFJLEVBQUU7UUFDWixXQUFXLE1BQU1DLFFBQVFILE9BQU87WUFDNUJFLElBQUlFLElBQUksQ0FBQ0Q7UUFDYjtRQUNBLDhEQUE4RDtRQUM5RCxPQUFPZixJQUFJaUIsSUFBSSxDQUFDSDtJQUNwQixFQUNBLE9BQU9JLEtBQUs7UUFDUkMsUUFBUUMsS0FBSyxDQUFDRjtRQUNkLE9BQU9sQixJQUFJaUIsSUFBSSxDQUFDO1lBQUUsWUFBWTtRQUF5QjtJQUMzRCxTQUNRO1FBQ0poQixTQUFTb0IsS0FBSztJQUNsQjtBQUNKO0FBR08sZUFBZUMsS0FBS2hCLEdBQUc7SUFDMUIsSUFBSTtRQUNBLE1BQU1MLFNBQVNNLE9BQU87UUFDdEJZLFFBQVFJLEdBQUcsQ0FBQztRQUNaLElBQUlSLE9BQU8sTUFBTVQsSUFBSVcsSUFBSTtRQUN6QixNQUFNVCxXQUFXUCxTQUFTUSxFQUFFLENBQUNQLFFBQVFDLEdBQUcsQ0FBQ08sUUFBUTtRQUNqRCxNQUFNQyxhQUFhSCxTQUFTRyxVQUFVLENBQUM7UUFDdkMsTUFBTWEsU0FBUyxNQUFNYixXQUFXYyxTQUFTLENBQUNWO1FBQzFDLHVCQUF1QjtRQUN2QixPQUFPZixJQUFJaUIsSUFBSSxDQUFDO1lBQUUsWUFBWTtZQUErQixRQUFRRixLQUFLVyxRQUFRO1FBQUM7SUFDdkYsRUFDQSxPQUFPUixLQUFLO1FBQ1Isc0JBQXNCO1FBQ3RCLE9BQU9sQixJQUFJaUIsSUFBSSxDQUFDO1lBQUUsWUFBWTtRQUF5QjtJQUMzRCxTQUNRO1FBQ0poQixTQUFTb0IsS0FBSztJQUNsQjtBQUVKIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbmV4dHRlbXAvLi9hcHAvYXBpL21vbmdvbG9naW4vcm91dGUuanM/NGMwNCJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCB7IE1vbmdvQ2xpZW50IH0gPSByZXF1aXJlKFwibW9uZ29kYlwiKTtcbmNvbnN0IHsgTmV4dFJlc3BvbnNlIH0gPSByZXF1aXJlKFwibmV4dC9zZXJ2ZXJcIik7XG5jb25zdCBkb3RlbnYgPSByZXF1aXJlKFwiZG90ZW52XCIpO1xuZG90ZW52LmNvbmZpZygpO1xuY29uc3QgcmVzID0gTmV4dFJlc3BvbnNlO1xuY29uc3QgZGJDbGllbnQgPSBuZXcgTW9uZ29DbGllbnQocHJvY2Vzcy5lbnYuQXRsYXNfVVJJKVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gR0VUKHJlcSkge1xuICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IGRiQ2xpZW50LmNvbm5lY3QoKVxuICAgICAgICBjb25zdCBkYXRhQmFzZSA9IGRiQ2xpZW50LmRiKHByb2Nlc3MuZW52LkF0bGFzX0RCKTtcbiAgICAgICAgY29uc3QgY29sbGVjdGlvbiA9IGRhdGFCYXNlLmNvbGxlY3Rpb24oJ3JlY29yZCcpO1xuICAgICAgICBjb25zdCBjdXJzb3I9Y29sbGVjdGlvbi5maW5kKClcbiAgICAgICAgY29uc3QgYXJyPVtdXG4gICAgICAgIGZvciBhd2FpdCAoY29uc3QgZGF0YSBvZiBjdXJzb3Ipe1xuICAgICAgICAgICAgYXJyLnB1c2goZGF0YSlcbiAgICAgICAgfVxuICAgICAgICAvLyByZXR1cm4gcmVzLmpzb24oeyAncmVzcG9uc2UnOiAnQXBpIGNhbGxlZCBTdWNjZXNzZnVsbHkhJyB9KVxuICAgICAgICByZXR1cm4gcmVzLmpzb24oYXJyKVxuICAgIH1cbiAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcbiAgICAgICAgcmV0dXJuIHJlcy5qc29uKHsgJ3Jlc3BvbnNlJzogJ0ludGVybmVsIFNlcnZlciBFcnJvciEnIH0pXG4gICAgfVxuICAgIGZpbmFsbHkge1xuICAgICAgICBkYkNsaWVudC5jbG9zZSgpXG4gICAgfVxufVxuXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBQT1NUKHJlcSkge1xuICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IGRiQ2xpZW50LmNvbm5lY3QoKTtcbiAgICAgICAgY29uc29sZS5sb2coJ2NsaWVudCBjb25uZWN0ZWQnKVxuICAgICAgICBsZXQgZGF0YSA9IGF3YWl0IHJlcS5qc29uKClcbiAgICAgICAgY29uc3QgZGF0YUJhc2UgPSBkYkNsaWVudC5kYihwcm9jZXNzLmVudi5BdGxhc19EQik7XG4gICAgICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBkYXRhQmFzZS5jb2xsZWN0aW9uKCdyZWNvcmQnKTtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY29sbGVjdGlvbi5pbnNlcnRPbmUoZGF0YSlcbiAgICAgICAgLy8gY29uc29sZS5sb2cocmVzdWx0KTtcbiAgICAgICAgcmV0dXJuIHJlcy5qc29uKHsgJ3Jlc3BvbnNlJzogXCJEYXRhIEluc2VydGVkIFN1Y2Nlc3NmdWxseSFcIiwgXCJVc2VyXCI6IGRhdGEuVXNlcm5hbWUgfSlcbiAgICB9XG4gICAgY2F0Y2ggKGVycikge1xuICAgICAgICAvLyBjb25zb2xlLmVycm9yKGVycik7XG4gICAgICAgIHJldHVybiByZXMuanNvbih7ICdyZXNwb25zZSc6ICdJbnRlcm5lbCBTZXJ2ZXIgRXJyb3IhJyB9KVxuICAgIH1cbiAgICBmaW5hbGx5IHtcbiAgICAgICAgZGJDbGllbnQuY2xvc2UoKVxuICAgIH1cblxufVxuIl0sIm5hbWVzIjpbIk1vbmdvQ2xpZW50IiwicmVxdWlyZSIsIk5leHRSZXNwb25zZSIsImRvdGVudiIsImNvbmZpZyIsInJlcyIsImRiQ2xpZW50IiwicHJvY2VzcyIsImVudiIsIkF0bGFzX1VSSSIsIkdFVCIsInJlcSIsImNvbm5lY3QiLCJkYXRhQmFzZSIsImRiIiwiQXRsYXNfREIiLCJjb2xsZWN0aW9uIiwiY3Vyc29yIiwiZmluZCIsImFyciIsImRhdGEiLCJwdXNoIiwianNvbiIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImNsb3NlIiwiUE9TVCIsImxvZyIsInJlc3VsdCIsImluc2VydE9uZSIsIlVzZXJuYW1lIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./app/api/mongologin/route.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/dotenv"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fmongologin%2Froute&page=%2Fapi%2Fmongologin%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fmongologin%2Froute.js&appDir=%2Fworkspaces%2Fnexttemp%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fworkspaces%2Fnexttemp&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();